package com.example.woshield;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Nearby_Safe extends AppCompatActivity implements OnMapReadyCallback {

    private static final String TAG = "Nearby_Safe";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;

    // Fallback baseline coordinates (Pune anchor) if GPS is cold or unavailable
    private static final double DEFAULT_LAT = 18.46225;
    private static final double DEFAULT_LON = 73.864972;

    private GoogleMap googleMap;
    private FusedLocationProviderClient fusedLocationClient;
    private LatLng currentUserLocation;

    private RecyclerView rvNearbyPlaces;
    private NearbySafePlaceAdapter adapter;
    private final List<NearbySafePlace> safePlacesList = new ArrayList<>();
    private final Map<String, Marker> placeMarkerMap = new HashMap<>();

    private ProgressBar progressBar;
    private TextView tvHeaderSubtitle;
    private TextView tvPlaceCountBadge;
    private BottomSheetBehavior<MaterialCardView> bottomSheetBehavior;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearby_safe);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        initViews();

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    private void initViews() {
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        tvHeaderSubtitle = findViewById(R.id.tv_header_subtitle);
        tvPlaceCountBadge = findViewById(R.id.tv_place_count_badge);
        progressBar = findViewById(R.id.progress_loading_places);

        rvNearbyPlaces = findViewById(R.id.rv_nearby_places);
        rvNearbyPlaces.setLayoutManager(new LinearLayoutManager(this));

        adapter = new NearbySafePlaceAdapter(safePlacesList, new NearbySafePlaceAdapter.OnSafePlaceClickListener() {
            @Override
            public void onPlaceClicked(NearbySafePlace place) {
                focusPlaceOnMap(place);
                showNavigateOptionDialog(place);
            }

            @Override
            public void onNavigateClicked(NearbySafePlace place) {
                focusPlaceOnMap(place);
                launchGoogleMapsNavigation(place);
            }

            @Override
            public void onCallClicked(NearbySafePlace place) {
                callHelpline(place.getPhone());
            }
        });
        rvNearbyPlaces.setAdapter(adapter);

        MaterialCardView bottomSheet = findViewById(R.id.bottom_sheet_places);
        if (bottomSheet != null) {
            bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }

        findViewById(R.id.btn_locate_me).setOnClickListener(v -> {
            if (currentUserLocation != null && googleMap != null) {
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentUserLocation, 15f));
                Toast.makeText(this, "Centered on your location", Toast.LENGTH_SHORT).show();
            } else {
                requestUserLocation();
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        googleMap = map;
        googleMap.getUiSettings().setZoomControlsEnabled(false);
        googleMap.getUiSettings().setCompassEnabled(true);
        googleMap.getUiSettings().setMyLocationButtonEnabled(false);

        googleMap.setOnMarkerClickListener(marker -> {
            Object tag = marker.getTag();
            if (tag instanceof NearbySafePlace) {
                NearbySafePlace place = (NearbySafePlace) tag;
                marker.showInfoWindow();
                showNavigateOptionDialog(place);
                // Also highlight in adapter
                int index = safePlacesList.indexOf(place);
                if (index != -1) {
                    adapter.setSelectedPosition(index);
                    rvNearbyPlaces.smoothScrollToPosition(index);
                }
                return true;
            }
            return false;
        });

        checkLocationPermissionAndFetch();
    }

    private void checkLocationPermissionAndFetch() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE
            );
            // In the meantime, seed around default location so user does not see a blank map
            seedSafePlacesAroundLocation(new LatLng(DEFAULT_LAT, DEFAULT_LON));
            return;
        }

        enableMapLocationLayer();
        requestUserLocation();
    }

    private void enableMapLocationLayer() {
        if (googleMap != null && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            try {
                googleMap.setMyLocationEnabled(true);
            } catch (SecurityException e) {
                Log.e(TAG, "SecurityException enabling MyLocation: " + e.getMessage());
            }
        }
    }

    private void requestUserLocation() {
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            seedSafePlacesAroundLocation(new LatLng(DEFAULT_LAT, DEFAULT_LON));
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                onLocationResolved(new LatLng(location.getLatitude(), location.getLongitude()));
            } else {
                // Request single fresh high accuracy update
                fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                        .addOnSuccessListener(this, freshLocation -> {
                            if (freshLocation != null) {
                                onLocationResolved(new LatLng(freshLocation.getLatitude(), freshLocation.getLongitude()));
                            } else {
                                onLocationResolved(new LatLng(DEFAULT_LAT, DEFAULT_LON));
                            }
                        })
                        .addOnFailureListener(this, e -> {
                            Log.w(TAG, "Failed to get fresh location, using default", e);
                            onLocationResolved(new LatLng(DEFAULT_LAT, DEFAULT_LON));
                        });
            }
        }).addOnFailureListener(this, e -> {
            Log.w(TAG, "Failed to get last location, using default", e);
            onLocationResolved(new LatLng(DEFAULT_LAT, DEFAULT_LON));
        });
    }

    private void onLocationResolved(LatLng location) {
        if (progressBar != null) progressBar.setVisibility(View.GONE);
        currentUserLocation = location;
        seedSafePlacesAroundLocation(currentUserLocation);
    }

    /**
     * Dynamically generates 5 realistic dummy safe places near the user's current location,
     * calculates distance, adds markers on Google Map, and binds them to the list.
     */
    private void seedSafePlacesAroundLocation(LatLng userLoc) {
        if (userLoc == null) return;
        currentUserLocation = userLoc;

        safePlacesList.clear();
        double uLat = userLoc.latitude;
        double uLng = userLoc.longitude;

        // 1. Police & Women Help Station (~290m North-East)
        double lat1 = uLat + 0.0024;
        double lng1 = uLng + 0.0019;
        safePlacesList.add(createSafePlace(
                "safe_place_1",
                "City Police & Women Assistance Desk",
                "POLICE",
                "Sector Main Junction, 24/7 Dedicated Women Helpdesk",
                lat1,
                lng1,
                uLat,
                uLng,
                "1091",
                "Open 24/7 • Dedicated Women Desk • Active Patrols",
                "Direct emergency assistance, police officer on duty, CCTV coverage."
        ));

        // 2. 24x7 Emergency Hospital (~520m South-East)
        double lat2 = uLat - 0.0036;
        double lng2 = uLng + 0.0028;
        safePlacesList.add(createSafePlace(
                "safe_place_2",
                "Lifeline 24x7 Emergency Hospital & Trauma Center",
                "HOSPITAL",
                "Health Boulevard, Emergency Casualty Ward Gate 1",
                lat2,
                lng2,
                uLat,
                uLng,
                "108",
                "Open 24/7 • Casualty & Trauma Care • Security Desk",
                "Well-lit emergency admission, 24-hour security guards and medical staff."
        ));

        // 3. Central Metro Transit Safe Point (~750m North-West)
        double lat3 = uLat + 0.0051;
        double lng3 = uLng - 0.0038;
        safePlacesList.add(createSafePlace(
                "safe_place_3",
                "Central Metro Transit Hub & Safety Kiosk",
                "TRANSIT",
                "Concourse Level 1, Under 360° CCTV Surveillance",
                lat3,
                lng3,
                uLat,
                uLng,
                "182",
                "Open 24/7 • Transit Police & SOS Helpline Kiosk",
                "Guarded entry gates, brightly illuminated concourse with SOS intercom."
        ));

        // 4. Apollo 24-Hour Pharmacy & Well-Lit Safe Point (~1.0 km South-West)
        double lat4 = uLat - 0.0065;
        double lng4 = uLng - 0.0052;
        safePlacesList.add(createSafePlace(
                "safe_place_4",
                "Apollo 24-Hour Pharmacy & Safe Haven",
                "SAFE HAVEN",
                "High Street Commercial Complex, Shop 14",
                lat4,
                lng4,
                uLat,
                uLng,
                "020-24201122",
                "Open 24/7 • Illuminated Storefront • First Aid Point",
                "All-night brightly lit safe waypoint with trained staff and first aid."
        ));

        // 5. Nirbhaya Women Safety Support Cell (~1.3 km North)
        double lat5 = uLat + 0.0082;
        double lng5 = uLng + 0.0064;
        safePlacesList.add(createSafePlace(
                "safe_place_5",
                "Nirbhaya Women Safety Support Cell & Shelter",
                "COMMUNITY HELP",
                "Civic Welfare Bhavan, Ground Floor Protection Wing",
                lat5,
                lng5,
                uLat,
                uLng,
                "181",
                "24/7 Shelter • Counseling & Emergency Escort Desk",
                "Recognized women crisis support center, immediate accommodation & escort."
        ));

        adapter.notifyDataSetChanged();

        if (tvHeaderSubtitle != null) {
            tvHeaderSubtitle.setText("5 safe havens near your location");
        }
        if (tvPlaceCountBadge != null) {
            tvPlaceCountBadge.setText("5 Safe Places");
        }

        plotPlacesOnMap();
    }

    private NearbySafePlace createSafePlace(String id, String name, String category, String address,
                                            double lat, double lng, double userLat, double userLng,
                                            String phone, String status, String notes) {
        float[] distResults = new float[1];
        Location.distanceBetween(userLat, userLng, lat, lng, distResults);
        float meters = distResults[0];

        String formattedDist;
        if (meters < 1000) {
            formattedDist = Math.round(meters) + " m away";
        } else {
            formattedDist = String.format(Locale.ENGLISH, "%.1f km away", meters / 1000f);
        }

        return new NearbySafePlace(id, name, category, address, lat, lng, meters, formattedDist, phone, status, notes);
    }

    private void plotPlacesOnMap() {
        if (googleMap == null || currentUserLocation == null) return;

        googleMap.clear();
        placeMarkerMap.clear();

        // Marker for user's current location
        googleMap.addMarker(new MarkerOptions()
                .position(currentUserLocation)
                .title("Your Current Location")
                .snippet("You are here")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));

        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();
        boundsBuilder.include(currentUserLocation);

        for (NearbySafePlace place : safePlacesList) {
            LatLng pos = new LatLng(place.getLatitude(), place.getLongitude());
            boundsBuilder.include(pos);

            float markerColor = BitmapDescriptorFactory.HUE_VIOLET;
            if ("POLICE".equalsIgnoreCase(place.getCategory())) {
                markerColor = BitmapDescriptorFactory.HUE_BLUE;
            } else if ("HOSPITAL".equalsIgnoreCase(place.getCategory())) {
                markerColor = BitmapDescriptorFactory.HUE_RED;
            } else if ("TRANSIT".equalsIgnoreCase(place.getCategory())) {
                markerColor = BitmapDescriptorFactory.HUE_CYAN;
            } else if ("SAFE HAVEN".equalsIgnoreCase(place.getCategory())) {
                markerColor = BitmapDescriptorFactory.HUE_GREEN;
            } else if ("COMMUNITY HELP".equalsIgnoreCase(place.getCategory())) {
                markerColor = BitmapDescriptorFactory.HUE_MAGENTA;
            }

            Marker marker = googleMap.addMarker(new MarkerOptions()
                    .position(pos)
                    .title(place.getName())
                    .snippet(place.getDistanceFormatted() + " • " + place.getAddress())
                    .icon(BitmapDescriptorFactory.defaultMarker(markerColor)));

            if (marker != null) {
                marker.setTag(place);
                placeMarkerMap.put(place.getId(), marker);
            }
        }

        try {
            LatLngBounds bounds = boundsBuilder.build();
            googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 180));
        } catch (Exception e) {
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentUserLocation, 14.5f));
        }
    }

    private void focusPlaceOnMap(NearbySafePlace place) {
        if (googleMap == null || place == null) return;
        LatLng pos = new LatLng(place.getLatitude(), place.getLongitude());
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(pos, 16f));

        Marker marker = placeMarkerMap.get(place.getId());
        if (marker != null) {
            marker.showInfoWindow();
        }
    }

    /**
     * Shows the Navigate option dialog when a safe place is clicked.
     */
    private void showNavigateOptionDialog(NearbySafePlace place) {
        if (place == null || isFinishing() || isDestroyed()) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_safe_place_navigate, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        TextView tvCategory = dialogView.findViewById(R.id.dialog_tv_category);
        TextView tvDistance = dialogView.findViewById(R.id.dialog_tv_distance);
        TextView tvName = dialogView.findViewById(R.id.dialog_tv_name);
        TextView tvAddress = dialogView.findViewById(R.id.dialog_tv_address);
        TextView tvStatus = dialogView.findViewById(R.id.dialog_tv_status);
        MaterialButton btnNavigate = dialogView.findViewById(R.id.dialog_btn_navigate);
        MaterialButton btnCall = dialogView.findViewById(R.id.dialog_btn_call);
        MaterialButton btnClose = dialogView.findViewById(R.id.dialog_btn_close);

        tvCategory.setText(place.getCategory() != null ? place.getCategory().toUpperCase() : "SAFE HAVEN");
        tvDistance.setText(place.getDistanceFormatted());
        tvName.setText(place.getName());
        tvAddress.setText(place.getAddress());
        tvStatus.setText(place.getStatus());

        // Navigate button action -> Redirects to Google Maps with direction route
        btnNavigate.setOnClickListener(v -> {
            dialog.dismiss();
            launchGoogleMapsNavigation(place);
        });

        // Call helpline action
        if (place.getPhone() != null && !place.getPhone().isEmpty()) {
            btnCall.setVisibility(View.VISIBLE);
            btnCall.setText("Call (" + place.getPhone() + ")");
            btnCall.setOnClickListener(v -> {
                dialog.dismiss();
                callHelpline(place.getPhone());
            });
        } else {
            btnCall.setVisibility(View.GONE);
        }

        btnClose.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    /**
     * Redirects to Google Maps app or browser showing the direction route
     * from user's current location to the safe place destination.
     */
    private void launchGoogleMapsNavigation(NearbySafePlace place) {
        if (place == null) return;

        Toast.makeText(this, "Opening direction route to " + place.getName(), Toast.LENGTH_SHORT).show();

        // Standard Google Maps Direction URL with origin (current location) and destination
        String uriString;
        if (currentUserLocation != null) {
            uriString = String.format(Locale.ENGLISH,
                    "https://www.google.com/maps/dir/?api=1&origin=%f,%f&destination=%f,%f&travelmode=walking",
                    currentUserLocation.latitude, currentUserLocation.longitude,
                    place.getLatitude(), place.getLongitude());
        } else {
            uriString = String.format(Locale.ENGLISH,
                    "https://www.google.com/maps/dir/?api=1&destination=%f,%f&travelmode=walking",
                    place.getLatitude(), place.getLongitude());
        }

        Uri gmmIntentUri = Uri.parse(uriString);
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        try {
            startActivity(mapIntent);
        } catch (ActivityNotFoundException e) {
            // Fallback: If Google Maps app is not installed, open through browser or any map handler
            Intent fallbackIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            try {
                startActivity(fallbackIntent);
            } catch (Exception ex) {
                Toast.makeText(this, "Could not open map: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void callHelpline(String phone) {
        if (phone == null || phone.isEmpty()) return;
        try {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + phone.trim()));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Could not initiate call: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableMapLocationLayer();
                requestUserLocation();
            } else {
                Toast.makeText(this, "Location permission denied. Showing places near default area.", Toast.LENGTH_LONG).show();
                seedSafePlacesAroundLocation(new LatLng(DEFAULT_LAT, DEFAULT_LON));
            }
        }
    }
}
