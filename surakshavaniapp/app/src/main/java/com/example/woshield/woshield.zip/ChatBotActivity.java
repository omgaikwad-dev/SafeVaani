package com.example.woshield;

import android.os.Bundle;
import android.util.Log;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ChatBotActivity extends AppCompatActivity {

    private static final String TAG = "ChatBotActivity";

    private RecyclerView chatRecyclerView;
    private EditText messageInput;
    private ImageView sendBtn;
    private ChatAdapter chatAdapter;
    private final List<ChatMessage> messageList = new ArrayList<>();
    private final List<GroqChatRequest.Message> conversationHistory = new ArrayList<>();
    private boolean isAwaitingResponse = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_bot);

        chatRecyclerView = findViewById(R.id.chatRecyclerView);
        messageInput = findViewById(R.id.messageInput);
        sendBtn = findViewById(R.id.sendBtn);
        ImageView backBtn = findViewById(R.id.backBtn);

        if (backBtn != null) {
            backBtn.setOnClickListener(v -> finish());
        }

        setupRecyclerView();
        initGroqAssistant();

        if (sendBtn != null) {
            sendBtn.setOnClickListener(v -> handleSendMessage());
        }

        if (messageInput != null) {
            messageInput.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    handleSendMessage();
                    return true;
                }
                return false;
            });
        }
    }

    private void setupRecyclerView() {
        chatAdapter = new ChatAdapter(messageList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        chatRecyclerView.setLayoutManager(layoutManager);
        chatRecyclerView.setAdapter(chatAdapter);
    }

    private void initGroqAssistant() {
        // System instruction for contextual safety advice
        conversationHistory.clear();
        conversationHistory.add(new GroqChatRequest.Message("system", GroqSafetyService.SYSTEM_SAFETY_PROMPT));

        // Default welcoming message
        addMessage("Hello! I am WoShield's AI Safety Assistant powered by Groq. How can I help you today? Ask me about personal safety advice, emergency steps, safe routes, or de-escalation tips.", false);
    }

    private void handleSendMessage() {
        if (isAwaitingResponse) {
            return;
        }

        String userInput = messageInput.getText().toString().trim();
        if (userInput.isEmpty()) {
            return;
        }

        // Post user message
        addMessage(userInput, true);
        conversationHistory.add(new GroqChatRequest.Message("user", userInput));
        messageInput.setText("");

        // Set UI loading state
        isAwaitingResponse = true;
        if (sendBtn != null) {
            sendBtn.setEnabled(false);
            sendBtn.setAlpha(0.5f);
        }

        // Add thinking indicator message
        final int thinkingIndex = messageList.size();
        addMessage("Safety Assistant is analyzing...", false);

        GroqSafetyService.getChatResponse(conversationHistory, new GroqSafetyService.SafetyChatCallback() {
            @Override
            public void onResponse(String response) {
                runOnUiThread(() -> {
                    isAwaitingResponse = false;
                    if (sendBtn != null) {
                        sendBtn.setEnabled(true);
                        sendBtn.setAlpha(1.0f);
                    }

                    // Replace the thinking message with actual response
                    if (thinkingIndex < messageList.size()) {
                        messageList.set(thinkingIndex, new ChatMessage(response, false));
                        chatAdapter.notifyItemChanged(thinkingIndex);
                    } else {
                        addMessage(response, false);
                    }
                    conversationHistory.add(new GroqChatRequest.Message("assistant", response));
                    chatRecyclerView.scrollToPosition(messageList.size() - 1);
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    isAwaitingResponse = false;
                    if (sendBtn != null) {
                        sendBtn.setEnabled(true);
                        sendBtn.setAlpha(1.0f);
                    }

                    String friendlyError = "I'm having trouble connecting right now (" + error + "). If you are in immediate danger, please call 112 or emergency services immediately.";
                    if (thinkingIndex < messageList.size()) {
                        messageList.set(thinkingIndex, new ChatMessage(friendlyError, false));
                        chatAdapter.notifyItemChanged(thinkingIndex);
                    } else {
                        addMessage(friendlyError, false);
                    }
                    chatRecyclerView.scrollToPosition(messageList.size() - 1);
                });
            }
        });
    }

    private void addMessage(String message, boolean isUser) {
        messageList.add(new ChatMessage(message, isUser));
        chatAdapter.notifyItemInserted(messageList.size() - 1);
        chatRecyclerView.scrollToPosition(messageList.size() - 1);
    }
}
